#!/usr/bin/python
import boto3
from retrying import retry
from terratest import TerraTest
from empty_bucket import empty_bucket


class TestSimpleBucketWithoutPolicy(TerraTest):
    """ Pytest Class to test the simple_bucket_without_policy example, 
    verifying the creation of the S3 Bucket. 
    """
    module_dir = "../examples/simple-bucket_mulitple_lifecycles/"

    @classmethod
    def setup_class(cls):
        super().setup_class()

        # Extract outputs
        tf_out = cls.terraform_outputs
        cls.expectedId = tf_out["id"]
        cls.expectedArn = tf_out["arn"]

        # Clients
        cls.s3Client = boto3.client("s3")

    @classmethod
    def teardown_class(cls):
        empty_bucket(cls.expectedId)
        super().teardown_class()

    def test_s3_simple_properties(self):
        """ Test function to verify that the S3 Bucket created exists 
        and its properties are correct.
        """

        # Check existence of bucket
        response = self.get_bucket_encryption(self.expectedId)
        assert response is not None

        # Check bucket's properties
        assert (
            response["ServerSideEncryptionConfiguration"]["Rules"][0][
                "ApplyServerSideEncryptionByDefault"
            ]["SSEAlgorithm"]
            == "AES256"
        )
        response = self.s3Client.get_bucket_versioning(Bucket=self.expectedId)
        assert response["Status"] == "Enabled"

    def test_lifecycle(self):

        response = self.get_bucket_lifecycle_configuration(self.expectedId)
        assert response is not None
        assert response["Rules"][0]["Status"] == "Enabled"
        assert response["Rules"][0]["Expiration"]["Days"] == 365
        assert response["Rules"][0]["Transitions"][0]["Days"] == 30
        assert (
            response["Rules"][0]["Transitions"][0]["StorageClass"]
            == "INTELLIGENT_TIERING"
        )
        assert response["Rules"][0]["Transitions"][1]["Days"] == 60
        assert response["Rules"][0]["Transitions"][1]["StorageClass"] == "GLACIER"
        assert (
            response["Rules"][0]["NoncurrentVersionTransitions"][0]["NoncurrentDays"]
            == 30
        )
        assert (
            response["Rules"][0]["NoncurrentVersionTransitions"][0]["StorageClass"]
            == "GLACIER"
        )

    @retry(
        stop_max_attempt_number=5,
        wait_exponential_multiplier=1000,
        wait_exponential_max=10000,
    )
    def get_bucket_encryption(self, bucket):
        return self.s3Client.get_bucket_encryption(Bucket=bucket)

    @retry(
        stop_max_attempt_number=5,
        wait_exponential_multiplier=1000,
        wait_exponential_max=10000,
    )
    def get_bucket_lifecycle_configuration(self, bucket):
        return self.s3Client.get_bucket_lifecycle_configuration(Bucket=bucket)
