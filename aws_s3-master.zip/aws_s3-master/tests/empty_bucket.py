import boto3


def empty_bucket(bucket_id):
    """
    Helper function to clear the contents/objects of a bucket.
    Terraform destroy can only be done on an empty bucket
    """
    print("deleting contents of" + bucket_id)
    # Get the s3 bucket resource
    s3 = boto3.resource("s3")
    bucket = s3.Bucket(bucket_id)

    # Remove all objects within the bucket
    bucket.object_versions.all().delete()
