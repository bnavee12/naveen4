from terraform_compliance_linter import Linter

class TestBucketCompliance:
    def test_bucket_compliance(self):
        linter = Linter("../examples")
        ignore_dirs = [
            "unsecured_bucket", "simple_bucket_without_policy", "simple_bucket_with_grant",
            #skipping terraform errors that are out of scope for these tests
            "bucket_with_tflife", "bucket_with_logging_and_tflife", "bucket_with_replication"
        ]
        linter.skip(ignore_dirs)
        #linter.run()
