import boto3
from terratest import TerraTest


class TestBucketWithLogging(TerraTest):
    module_dir = "../examples/bucket_with_logging"
    s3 = boto3.client('s3')

    def test_bucket_names(self):
        assert self.terraform_outputs['bucket_id']\
            .endswith('-bucket-with-logging-example')
        assert self.terraform_outputs['log_bucket_id'] \
            .endswith('-bucket-with-logging-logs-example')

    def test_buckets_exist(self):
        self.s3.head_bucket(
            Bucket=self.terraform_outputs['bucket_id']
        )
        self.s3.head_bucket(
            Bucket=self.terraform_outputs['log_bucket_id']
        )

    def test_bucket_logging_is_configured(self):
        main_bucket = self.terraform_outputs['bucket_id']
        log_bucket = self.terraform_outputs['log_bucket_id']

        main_bucket_logging = self.s3.get_bucket_logging(
            Bucket=main_bucket
        )
        assert main_bucket_logging['LoggingEnabled']['TargetBucket'] == log_bucket
        assert main_bucket_logging['LoggingEnabled']['TargetPrefix'] == "logs/"

        # Logging bucket should log to itself, as well
        log_bucket_logging = self.s3.get_bucket_logging(
            Bucket=log_bucket
        )
        assert log_bucket_logging['LoggingEnabled']['TargetBucket'] == log_bucket
        # TODO: this prefix should be different, so logs aren't mixed in with logs
        #       from the main bucket.
        #       See https://github.optum.com/CommercialCloud-EAC/aws_s3/issues/78
        assert log_bucket_logging['LoggingEnabled']['TargetPrefix'] == "logs/"
