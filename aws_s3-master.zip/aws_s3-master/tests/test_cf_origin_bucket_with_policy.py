#!/usr/bin/python
import boto3
from retrying import retry
from terratest import TerraTest
from empty_bucket import empty_bucket


class TestCFOriginBucketWithPolicy(TerraTest):
    """ Pytest Class to test the cf_origin_bucket_with_policy example, 
    verifying the creation of all of the S3 Bucket resources.
    """
    module_dir = "../examples/cf_origin_bucket_with_policy/"

    @classmethod
    def setup_class(cls):
        super().setup_class()

        # Extract outputs
        tf_out = cls.terraform_outputs
        cls.expectedCFBucketId = tf_out["id"]
        cls.expectedCFBucketArn = tf_out["arn"]
        cls.expectedLogBucketId = tf_out["log_bucket_id"]
        cls.expectedLogBucketArn = tf_out["log_bucket_arn"]
        cls.expectedDomainName = tf_out["domain_name"]

        # Clients
        cls.s3Client = boto3.client("s3")

    @classmethod
    def teardown_class(cls):
        # Clear contents of bucket (terraform can only destroy an empty bucket)
        empty_bucket(cls.expectedCFBucketId)
        empty_bucket(cls.expectedLogBucketId)

        super().teardown_class()

    def test_s3_cf_bucket_properties(self):
        """ Test function to verify that the S3 CF Bucket created exists 
        and its properties are correct.
        """

        # Check existence of bucket
        response = self.get_bucket_encryption(self.expectedCFBucketId)
        assert response is not None

        # Check bucket's properties
        assert (
            response["ServerSideEncryptionConfiguration"]["Rules"][0][
                "ApplyServerSideEncryptionByDefault"
            ]["SSEAlgorithm"]
            == "AES256"
        )
        response = self.s3Client.get_bucket_versioning(
            Bucket=self.expectedCFBucketId)
        assert response["Status"] == "Enabled"
        response = self.s3Client.get_bucket_cors(
            Bucket=self.expectedCFBucketId)
        assert response["CORSRules"][0]["AllowedHeaders"] == ["*"]
        assert response["CORSRules"][0]["AllowedMethods"] == ["POST"]
        assert response["CORSRules"][0]["AllowedOrigins"] == ["*"]
        assert response["CORSRules"][0]["ExposeHeaders"] == ["ETag"]
        assert response["CORSRules"][0]["MaxAgeSeconds"] == 3000

    def test_s3_log_bucket_properties(self):
        """ Test function to verify that the S3 Log Bucket created exists 
        and its properties are correct.
        """

        # Check existence of bucket
        response = self.get_bucket_encryption(self.expectedLogBucketId)
        assert response is not None

        # Check bucket's properties
        assert (
            response["ServerSideEncryptionConfiguration"]["Rules"][0][
                "ApplyServerSideEncryptionByDefault"
            ]["SSEAlgorithm"]
            == "AES256"
        )
        response = self.s3Client.get_bucket_versioning(
            Bucket=self.expectedCFBucketId)
        assert response["Status"] == "Enabled"

        # Check that this bucket is the target logging bucket
        response = self.s3Client.get_bucket_logging(
            Bucket=self.expectedCFBucketId)
        assert response["LoggingEnabled"]["TargetBucket"] == self.expectedLogBucketId

    @retry(
        stop_max_attempt_number=5,
        wait_exponential_multiplier=1000,
        wait_exponential_max=10000,
    )
    def get_bucket_encryption(self, bucket):
        return self.s3Client.get_bucket_encryption(Bucket=bucket)
