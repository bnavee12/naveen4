# AWS S3 Bucket

![Maintenance](https://img.shields.io/maintenance/yes/2021?label=Cloud%20Ops%20Supported)
[![Build Status](https://jenkins-oa-cloud-operations.origin-ctc-core.optum.com/job/oaccoe/job/aws_s3/job/master/badge/icon)](https://jenkins-oa-cloud-operations.origin-ctc-core.optum.com/job/oaccoe/job/aws_s3/)

This module is been updated to terraform version 0.14 which is the current master branch. Previous version v0.12 is been created as a separate branch named as "v0.12" and the related tag/releases are also created.Center Of excellence team suggests to start using terraform version v0.14 and would support the modules accordingly.

## Contents

- [Overview](#overview)
- [Requirements](#requirements)
- [Profiles](#profiles)
- [Usage](#usage)
- [Products currently using this module](#Products-currently-using-this-module)
- [Known Issues](#known-issues)
- [Launchpad Policies](#launchpad-policies)
- [Referrenced Modules](#referrenced-modules)
- [Support Details](#Support-Details)


## Overview

This repository describes the setup and implmentation of **AWS S3 Bucket** using terraform.

AWS S3 provides a service that store and retreive files from AWS from anywhere on the web, [see this document](http://docs.aws.amazon.com/AmazonS3/latest/dev/Welcome.html)

###Terraform

### Features:
* Creates proper S3 buckets and permissions
* Can automatically setup versioning for S3 buckets, default encryption, lifecycle events, logging etc for S3 buckets
* Create S3 bucket compatible as a Cloud Front origin to host static contents
* **Will Force Destroy Buckets By Default** this is to ensure that buckets will not be left in insecure states when terraform attempts to destroy them
* Made all the S3 bucket policies to be inline to the S3 bucket to avoid security violation alert when the s3 bucket deletion failed while bucket policy got deleted.

### S3 Bucket Properties:
There are optional properties that can be applied to S3 buckets. The following properties are available in this module:

|S3 Bucket Property|Description              |
|----------------|-------------------------------|
|Terraform Lifecycle Management|Prevents a Terraform resource from being destroyed accidentally|
|Logging             |Tracks access requests to the S3 bucket|
|Website Hosting via CloudFront|Static website hosting from the S3 bucket|
|Cross Region Replication |Enables automatic, asynchronous replication of S3 objects across buckets|

The following grid shows the proper Terraform profiles folder to use when applying S3 properties:

|Profile Path    |Logging|Terraform Lifecycle |Website Hosting via CloudFront|Cross Region Replication|
|---------------|----|-------|-------|-----------|
|profiles/simple-with-storage-class    | | | | |
|profiles/simple    | | | | |
|profiles/log       |X| | | |
|profiles/existing-log       |X| | | |
|profiles/tflife    | |X| | |
|profiles/tflife-log|X|X| | |
|profiles/tflife-existing-log|X|X| | |
|profiles/cf-origin       | | |X| |
|profiles/rep       | | | |X|
|profiles/rep-log   |X| | |X|

#### Testing:

Test are written in python, using [`TerraTestPy`](https://commercialcloud.optum.com/docs/technical-guides/testing-terraform-modules.html). The tests are all integration tests:

- Deploy a terraform configuration
- Test against the deployed infrastructure using the AWS Python SDK (boto3)
- Tear down the terraform configuration

To run tests:

* [Login to an AWS testing account](https://github.optum.com/CommercialCloud-EAC/python-scripts/tree/master/aws-cli-saml)
* Ensure that python3.6+ is installed.
* Find the test you want to run in the `/tests/` directory


Create a virtualenv for  your test
````
$ cd tests/
$ python3 -m venv venv
$ source venv/bin/activate
(venv)$ pip install -r requirements.txt 
````

Run the pytest against your test
```
$ pytest test_unsecured_bucket.py 
```

To run all tests at once:

```
$ pytest
```

The tests should all pass.

Examples
--------

Examples are included in this repository, for more information see the examples folder.
**NOTE:** 
1. Not all AWS projects may benefit from using S3. 
2. modules/* (no underscore) is symlinked to profiles/* for backwards compatibility to avoid breaking changes for existing user.

![aws_s3](./assets/aws_s3.png)

[Contribute](/contributing.md) to this repository.

## Requirements

Supports:

- Terraform ~> 0.14.10
- provider.aws ~> 2.7.0


## Profiles

### [Simple S3 bucket](/profiles/simple) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/adequate.png" height="24px" />

This profile adds a simple S3 Bucket with a default private acl. It is ideal for development purposes only and should not be used in a production environment.

### [Simple bucket with Storage Class](/profiles/simple-with-storage-class) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/adequate.png" height="24px" />

This is a sub-module of the aws_s3 Terraform module. A simple S3 Bucket with a default private acl, allows transition of objects from S3 Standard to other storage class(intial) after specified number of days from the time object is created and from intial storage class object is transtioned to another storage class(final, should be compatible) after specified period  from the time object is created, noncurrent objects are transitioned from S3 Standard to other storage class after specified number of days from the time object has become noncurrent.Object expires after specified expiration days.

### [S3 bucket for Website Hosting via CloudFront](/profiles/cf-origin) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/adequate.png" height="24px" />

This profile adds a S3 Bucket with capabilities for Website Hosting via CloudFront (static website hosting from an S3 Bucket).

### [Create S3 bucket with a new log bucket](/profiles/log) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/best.png" height="24px" />

This profile adds a S3 Bucket with capabilities to log its access requests to a another new S3 Bucket.

### [Create S3 bucket with an Existing log bucket](/profiles/existing-log) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/best.png" height="24px" />

This profile adds a simple S3 Bucket with capabilities to log its access requests to another existing S3 Bucket.

### [S3 bucket with capabilities of Cross Region Replication](/profiles/rep) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/adequate.png" height="24px" />

This profile adds a S3 Bucket with capabilities of Cross Region Replication, enabling automatic asynchronous replication of S3 object across Buckets.

### [S3 bucket with Cross Region Replication and with a new S3 log Bucket](/profiles/rep-log) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/best.png" height="24px" />

This profile adds a simple S3 Bucket with capabilities of Cross Region Replication and log its access requests to a new S3 Bucket.

### [S3 bucket With a Terraform lifecycle Example](/profiles/tflife) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/adequate.png" height="24px" />

This profile adds a simple S3 Bucket with the capability to prevent a Terraform destroy deleting the resource.

### [S3 bucket With multiple lifecycle](/profiles/simple-multiple-lifecycle) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/adequate.png" height="24px" />

The profile adds a simple S3 bucket and allows objects to be transitioned from S3 Standard to other storage classes (initial) after a specified number of days since they were created.

### [S3 bucket with Terraform Lifecycle and logging with new S3 bucket](/profiles/tflife-log) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/best.png" height="24px" />

This profile adds a S3 Bucket with the capability to prevent a Terraform destroy deleting the resource and log its access requests to an another new S3 Bucket.

### [S3 bucket with Terraform Lifecycle and logging with existing S3 bucket](/profiles/cf-origin) <img src="https://dojo.o360.cloud/wp-content/uploads/2020/09/best.png" height="24px" />

This profile adds a simple S3 Bucket with the capability to prevent a Terraform destroy deleting the resource.


## Usage

Usage is specific to the selected profile. Please refer to the profile README for its usage.

## Products currently using this module
Below Product teams are currently using this module
1.  Link
2.  OPA
3.  OMA
4.  CDP
5.  CCC
6.  SPC
7.  OADW

## Known Issues

The replication profile in this module may through Access denied error when trying to create bucket in other region. This is due to the restriction at the AWS organisation level by HCC.  

## Launchpad Policies

Health Care Cloud and Enterprise Information Security collaborate on an ongoing collection of security policies to identify and address severe security vulnerabilities. List of AWS Launchpad Policies are available [here](https://cloud.optum.com/docs/launchpad/aws-policies/). This module helps to prevent the below Launchpad Violations:

* [AWS S3 Bucket has Global Permissions enabled via bucket policy](https://cloud.optum.com/docs/launchpad/aws-policies/AWS_S3_Bucket_has_Global_Permissions_enabled_via_bucket_policy)
* [AWS S3 bucket has global view ACL permissions enabled](https://cloud.optum.com/docs/launchpad/aws-policies/AWS_S3_bucket_has_global_view_ACL_permissions_enabled)
* [AWS S3 bucket not configured with secure data transport policy UHG](https://cloud.optum.com/docs/launchpad/aws-policies/AWS_S3_bucket_not_configured_with_secure_data_transport_policy_UHG)
* [AWS S3 buckets are accessible to public](https://cloud.optum.com/docs/launchpad/aws-policies/AWS_S3_buckets_are_accessible_to_public)
* [AWS S3 buckets do not have server side encryption - UHG](https://cloud.optum.com/docs/launchpad/aws-policies/AWS_S3_buckets_do_not_have_server_side_encryption_-_UHG)
* [UHG AWS S3 Bucket has Global PUT Permissions enabled via bucket policy](https://cloud.optum.com/docs/launchpad/aws-policies/UHG_AWS_S3_Bucket_has_Global_PUT_Permissions_enabled_via_bucket_policy)


## Referrenced Modules

No modules are referred within this module.


## Support Details:

📧 - OA_Cloud_Support@ds.uhc.com
