# Profile: S3 bucket with Terraform Lifecycle and logging with existing S3 bucket

## Contents

- [Overview](#overview)
- [Requirements](#requirements)
- [Argument Reference](#argument-reference)
- [Attributes Reference](#attributes-reference)
- [Usage](#usage)
- [Known Issues](#known-issues)

## Overview

This profile adds a **simple S3 Bucket** with the capability to prevent a Terraform ```destroy``` deleting the resource.

Note: the items/files starting with "common_" are symbolic links to cooresponding files in the "../../_modules/common/"
sub-module directory.

[Contribute](/contributing.md) to this repository.

## Requirements

Supports:

- Terraform ~> 0.14.10


## Argument Reference

The following arguments are supported:


|Variable    |Description              |Default              |
|------------|-------------------------|---------------------|
|name         |Name of the S3 bucket (must be globally unique S3 name)|{name_prefix}{name_suffix}|
|name_prefix    |Base name for the S3 bucket|{aws_account_id}-|
|name_suffix  |Suffix name for the S3 bucket|default|
|acl | The canned ACL to apply | `private` |
|custom_policy|IAM custom policy to attach to the S3 bucket                       |`null`|
|force_destroy|Terraform will remove all objects from the S3 bucket; then delete the bucket|false|
|versioning_enabled|Enable AWS versioning on the S3 bucket                        |false|
|sse_algorithm|Enable encryption on the S3 bucket                               |`AES256`|
|S3ssl_enforced |Enforce SSL data transfer on the S3 bucket                         |`true`|
|kms_master_key_id   |ARN referencing the KMS key If encryption type is `aws:kms`; ignored if not using `aws:kms` encryption|`null`|
|roles        |IAM roles to attach to the S3 bucket                               |(See more details below)|
|tags                |Map of tags to apply to this single s3 module                      |`null`|
|global_tags         |Map of tags to apply to all resources that have tags parameters    |`null`|
| block_public_acls | Whether Amazon S3 should block public ACLs for this bucket | false |
| block_public_policy | Whether Amazon S3 should block public bucket policies for this bucket | false |
| ignore_public_acls | Whether Amazon S3 should ignore public ACLs for this bucket | false |
| restrict_public_buckets | Whether Amazon S3 should restrict public bucket policies for this bucket | false |
| cors_rule | List of maps containing rules for Cross-Origin Resource Sharing | `null` |
| grant | List of maps containing ACL policy grant. Not used with `acl`, and a non-empty value will default it to `null` | `null` |

## Attributes Reference

The following attributes are exported:

|Output        |Description           |
|--------------|----------------------|
|id     |Name of the S3 bucket   |
|arn    |ARN of the S3 bucket  |
|bucket_regional_domain_name  |The bucket region-specific domain name |

## Usage

```hcl
# Create Bucket With a Terraform lifecycle Example

data "aws_caller_identity" "current" {}

locals {
  aws_account_id = "${data.aws_caller_identity.current.account_id}"
}

# Configure the AWS Provider
provider "aws" {
  access_key = "${var.aws_access_key}"
  secret_key = "${var.aws_secret_key}"
  region     = "${var.aws_region}"
}

module "bucket-for-logging" {
  source = "../../profiles/tflife"
  name   = "${local.aws_account_id}-bucket-with-logging-and-tflife-logs"
  acl    = "log-delivery-write"
}

module "bucket_with_logging_and_tflife" {
  source                   = "../../profiles/tflife-existing-log"
  name_suffix              = "bucket-with-logging-and-tflife"
  log_bucket_name          = "${local.aws_account_id}-bucket-with-logging-and-tflife-logs"
  log_bucket_custom_policy = ""
  namespace                = "example"                                                     # Can't do random namespace due to interpolation error

  global_tags = {
    global_tag = "example"
  }

  tags = {
    Name = "bucket-with-logging-and-tflife"
  }
}

```
***Note***: Please refer [Examples](/examples) for complete usage.

## Known Issues

None at this time.
