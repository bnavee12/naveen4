# Profile: Simple S3 bucket

## Contents

- [Overview](#overview)
- [Requirements](#requirements)
- [Argument Reference](#argument-reference)
- [Attributes Reference](#attributes-reference)
- [Usage](#usage)
- [Known Issues](#known-issues)

## Overview

This profile adds a **simple S3 Bucket** with a default private acl.

Note: the items/files starting with "common_" are symbolic links to cooresponding files in the "../../_modules/common/"
sub-module directory.

[Contribute](/contributing.md) to this repository.

## Requirements

Supports:

- Terraform ~> 0.14.10


## Argument Reference

The following arguments are supported:

|Variable    |Description              |Default              |
|------------|-------------------------|---------------------|
|name         |Name of the S3 bucket (must be globally unique S3 name)|{name_prefix}{name_suffix}|
|name_prefix    |Base name for the S3 bucket|{aws_account_id}-|
|name_suffix  |Suffix name for the S3 bucket|default|
|acl | The canned ACL to apply | `private` |
|custom_policy|IAM custom policy to attach to the S3 bucket                       |`null`|
|force_destroy|Terraform will remove all objects from the S3 bucket; then delete the bucket|false|
|versioning_enabled|Enable AWS versioning on the S3 bucket                        |false|
|sse_algorithm|Enable encryption on the S3 bucket                               |`AES256`|
|S3ssl_enforced |Enforce SSL data transfer on the S3 bucket                         |`true`|
|kms_master_key_id   |ARN referencing the KMS key If encryption type is `aws:kms`; ignored if not using `aws:kms` encryption|`null`|
|roles        |IAM roles to attach to the S3 bucket                               |(See more details below)|
|tags                |Map of tags to apply to this single s3 module                      |`null`|
|global_tags         |Map of tags to apply to all resources that have tags parameters    |`null`|
|logging             |Map that enables logging properties. Supports `target_bucket` and `target_prefix`. If `target_bucket` is not specified, it will log to itself by default |{}|
| block_public_acls | Whether Amazon S3 should block public ACLs for this bucket | false |
| block_public_policy | Whether Amazon S3 should block public bucket policies for this bucket | false |
| ignore_public_acls | Whether Amazon S3 should ignore public ACLs for this bucket | false |
| restrict_public_buckets | Whether Amazon S3 should restrict public bucket policies for this bucket | false |
| cors_rule | List of maps containing rules for Cross-Origin Resource Sharing | `null` |
| grant | List of maps containing ACL policy grant. Not used with `acl`, and a non-empty value will default it to `null` | `null` |

## Attributes Reference

The following attributes are exported:

|Output        |Description           |
|--------------|----------------------|
|id     |Name of the S3 bucket   |
|arn    |ARN of the S3 bucket  |
|bucket_regional_domain_name  |The bucket region-specific domain name |

## Usage

```hcl
# Create Simple Bucket Without a Policy Example

# Configure the AWS Provider
provider "aws" {
  region     = "${var.aws_region}"
}

module "simple-bucket-without-policy" {
  source        = "git::https://github.optum.com/oaccoe/aws_s3.git//profiles/simple"
  name_suffix   = "simple-bucket-without-policy"
  custom_policy = ""
  namespace     = "example"

  global_tags = {
    global_tag = "example"
  }

  tags = {
    Name = "simple-bucket-without-policy"
  }
}
```
***Note***: Please refer [Examples](/examples) for complete usage.

## Known Issues

None at this time.
