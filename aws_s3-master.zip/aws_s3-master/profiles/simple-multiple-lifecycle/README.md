# Simple bucket with multiple lifecycle poilcies
## Contents

- [Overview](#overview)
- [Argument Reference](#argument-reference)
- [Attributes Reference](#attributes-reference)
- [Usage](#usage)
- [Known Issues](#known-issues)

## Overview

A simple S3 Bucket with a default private acl, allows transition of objects from S3 Standard to other storage class(intial) after specified number of days from the time object is created and from intial storage class object is transtioned to another storage class(final, should be compatible) after specified period  from the time object is created, noncurrent objects are transitioned from S3 Standard to other storage class after specified number of days from the time object has become noncurrent.Object expires after specified expiration days.

Note: the items/files starting with "common_" are symbolic links to cooresponding files in the "..\common"
sub-module directory.

## Argument Reference

The following arguments are supported:

|Variable    |Description              |Default              |
|------------|-------------------------|---------------------|
|name         |Name of the S3 bucket (must be globally unique S3 name)|{name_prefix}{name_suffix}|
|name_prefix    |Base name for the S3 bucket|{aws_account_id}-|
|name_suffix  |Suffix name for the S3 bucket|default|
|lifecycle_rule|configuration of object lifecycle management.|[]|
|acl | The canned ACL to apply | `private` |
|custom_policy|IAM custom policy to attach to the S3 bucket                       |`null`|
|force_destroy|Terraform will remove all objects from the S3 bucket; then delete the bucket|false|
|versioning_enabled|Enable AWS versioning on the S3 bucket                        |false|
|sse_algorithm|Enable encryption on the S3 bucket                               |`AES256`|
|S3ssl_enforced |Enforce SSL data transfer on the S3 bucket                         |`true`|
|kms_master_key_id   |ARN referencing the KMS key If encryption type is `aws:kms`; ignored if not using `aws:kms` encryption|`null`|
|roles        |IAM roles to attach to the S3 bucket                               |(See more details below)|
|tags                |Map of tags to apply to this single s3 module                      |`null`|
|global_tags         |Map of tags to apply to all resources that have tags parameters    |`null`|
|prefix       |Filter to select objects for transition empty value indicates whole bucket|`null`|
| block_public_acls | Whether Amazon S3 should block public ACLs for this bucket | false |
| block_public_policy | Whether Amazon S3 should block public bucket policies for this bucket | false |
| ignore_public_acls | Whether Amazon S3 should ignore public ACLs for this bucket | false |
| restrict_public_buckets | Whether Amazon S3 should restrict public bucket policies for this bucket | false |
| cors_rule | List of maps containing rules for Cross-Origin Resource Sharing | `null` |
| grant | List of maps containing ACL policy grant. Not used with `acl`, and a non-empty value will default it to `null` | `null` |

## Attributes Reference

The following attributes are exported:

|Output        |Description           |
|--------------|----------------------|
|id     |Name of the S3 bucket   |
|arn    |ARN of the S3 bucket  |

## Usage

```hcl
# Create Simple Bucket With Storage Classes
# Configure the AWS Provider
provider "aws" {
  region = "${var.aws_region}"
}

module "simple-bucket-multiple-lifecycle-policy" {
  source = "../../profiles/simple-multiple-lifecycle"
  name_suffix                   = ""
  custom_policy                 = ""
  namespace                     = "namespace"
  versioning_enabled            = "true"
  lifecycle_rule = [
    {
      id      = "log"
      enabled = true
      prefix  = "log/"

      tags = {
        rule      = "log"
        autoclean = "true"
      }

      transition = [
        {
          days          = 30
          storage_class = "INTELLIGENT_TIERING"
          }, {
          days          = 60
          storage_class = "GLACIER"
        }
      ]

      expiration = {
        days = 365
      }

      noncurrent_version_transition = [
        {
          days          = 30
          storage_class = "GLACIER"
        },
      ]
    },
    {
       id                                     = "log1"
       enabled                                = true
       prefix                                 = "log1/"
       abort_incomplete_multipart_upload_days = 7

       noncurrent_version_transition = [
         {
           days          = 30
           storage_class = "STANDARD_IA"
         },
         {
           days          = 60
           storage_class = "ONEZONE_IA"
         },
         {
           days          = 90
           storage_class = "GLACIER"
         },
       ]

       noncurrent_version_expiration = {
         days = 300
       }
    },
  ]
    
  global_tags = {
    global_tag = "example-testing"
  }

  tags = {
    Name = "simple-bucket-with-storage-class-without-policy"
  }
}
```

## Known Issues

None at this time.
