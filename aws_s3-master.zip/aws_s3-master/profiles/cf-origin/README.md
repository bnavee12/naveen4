# Profile: S3 bucket for Website Hosting via CloudFront

## Contents

- [Overview](#overview)
- [Requirements](#requirements)
- [Argument Reference](#argument-reference)
- [Attributes Reference](#attributes-reference)
- [Usage](#usage)
- [Known Issues](#known-issues)

## Overview

This profile adds **an S3 Bucket** with capabilities for **Website Hosting via CloudFront** (static website hosting from an S3 Bucket).

Note: the items/files starting with "common_" are symbolic links to cooresponding files in the "../../_modules/common/"
sub-module directory.

[Contribute](/contributing.md) to this repository.

## Requirements

Supports:

- Terraform ~> 0.14.10


## Argument Reference

The following arguments are supported:

|Variable    |Description              |Default              |
|------------|-------------------------|---------------------|
|name         |Name of the S3 bucket (must be globally unique S3 name)|{name_prefix}{name_suffix}|
|name_prefix    |Base name for the S3 bucket|{aws_account_id}-|
|name_suffix  |Suffix name for the S3 bucket|default|
|acl | The canned ACL to apply | `private` |
|custom_policy|IAM custom policy to attach to the S3 bucket                       |`null`|
|force_destroy|Terraform will remove all objects from the S3 bucket; then delete the bucket|false|
|versioning_enabled|Enable AWS versioning on the S3 bucket                        |false|
|sse_algorithm|Enable encryption on the S3 bucket                               |`AES256`|
|S3ssl_enforced |Enforce SSL data transfer on the S3 bucket                         |`true`|
|kms_master_key_id   |ARN referencing the KMS key If encryption type is `aws:kms`; ignored if not using `aws:kms` encryption|`null`|
|roles        |IAM roles to attach to the S3 bucket                               |(See more details below)|
|tags                |Map of tags to apply to this single s3 module                      |`null`|
|global_tags         |Map of tags to apply to all resources that have tags parameters    |`null`|
|cf_origin_access_identity_arn    | CloudFront origin access identity arn for bucket policy | `` |
|cf_origin_cors_allowed_headers   | Specifies which headers are allowed (list)              | ["*"] |
|cf_origin_cors_allowed_methods   | Specifies which methods are allowed. Can be GET, PUT, POST, DELETE or HEAD (list) | ["GET", "PUT", "POST"] |
|cf_origin_cors_allowed_origins   | Specifies which origins are allowed(list)                     | ["*"] |
|cf_origin_cors_expose_headers    | Specifies expose header in the response                       | ["ETag"] |
|cf_origin_cors_max_age_seconds   | Specifies time in seconds that browser can cache the response for a preflight request | 3000 |
|cf_origin_logging_bucket_name    | The name of the bucket that will receive the log objects      | ``|
|cf_origin_logging_bucket_target_prefix | The name of the key prefix for log objects              | `` |  
|cf_origin_force_destroy          | A boolean that indicates all objects should be deleted from the bucket so that the bucket can be destroyed without error | false |
| block_public_acls | Whether Amazon S3 should block public ACLs for this bucket | false |
| block_public_policy | Whether Amazon S3 should block public bucket policies for this bucket | false |
| ignore_public_acls | Whether Amazon S3 should ignore public ACLs for this bucket | false |
| restrict_public_buckets | Whether Amazon S3 should restrict public bucket policies for this bucket | false |
| grant | List of maps containing ACL policy grant. Not used with `acl`, and a non-empty value will default it to `null` | `null` |



## Attributes Reference

The following attributes are exported:

|Output        |Description           |
|--------------|----------------------|
|id     |Name of the S3 bucket   |
|arn    |ARN of the S3 bucket  |
|cf_origin_bucket_domain_name | The domain name of the static content bucket |
|bucket_regional_domain_name | The bucket region-specific domain name |

## Usage

```hcl
# Create Bucket With a Policy Example

module "cf-origin-bucket-with-policy" {
  source                                 = "git::https://github.optum.com/oaccoe/aws_s3.git//profiles/cf-origin"
  name_suffix                            = "cf-origin-bucket"
  namespace                              = "example"                                                             # Can't do random namespace due to interpolation error with policies
  custom_policy                          = "${data.aws_iam_policy_document.custom_policy.json}"
  versioning_enabled                     = "true"
  cf_origin_access_identity_arn          = "${aws_cloudfront_origin_access_identity.for_static_content.iam_arn}"
  cf_origin_cors_allowed_headers         = ["*"]
  cf_origin_cors_allowed_methods         = ["POST"]
  cf_origin_logging_bucket_name          = "${module.log_bucket.id}"
  cf_origin_logging_bucket_target_prefix = "cf-s3-log/"

  global_tags = {
    global_tag = "example"
  }

  tags = {
    Name = "cf-origin-bucket-with-policy-and-role"
  }
}
```
***Note***: Please refer [Examples](/examples) for complete usage.

## Known Issues

None at this time.
